DB: MongoDB

Publisher attributes:

	private String name; - @Id
	private String address;
	private String phoneNumber;
	private String webSiteUrl;